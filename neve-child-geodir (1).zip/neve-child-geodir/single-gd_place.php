<?php
defined('ABSPATH') || exit;
get_header();
the_post();

$post_id = get_the_ID();

// Collect common GeoDirectory meta keys (adjust as needed)
$addr = '';
$meta_keys_addr = array('geodir_address','post_address','address','geodir_default_address');
foreach ($meta_keys_addr as $k) {
  $v = get_post_meta($post_id, $k, true);
  if (!empty($v)) { $addr = $v; break; }
}
$phone = '';
$meta_keys_phone = array('geodir_phone','phone','telefone');
foreach ($meta_keys_phone as $k) {
  $v = get_post_meta($post_id, $k, true);
  if (!empty($v)) { $phone = $v; break; }
}
$whatsapp = '';
$meta_keys_whatsapp = array('geodir_whatsapp','whatsapp','post_whatsapp');
foreach ($meta_keys_whatsapp as $k) {
  $v = get_post_meta($post_id, $k, true);
  if (!empty($v)) { $whatsapp = preg_replace('/\D+/', '', $v); break; }
}
$website = '';
$meta_keys_site = array('geodir_website','website','post_website');
foreach ($meta_keys_site as $k) {
  $v = get_post_meta($post_id, $k, true);
  if (!empty($v)) { $website = $v; break; }
}
$email = '';
$meta_keys_email = array('geodir_email','email','post_email','_email');
foreach ($meta_keys_email as $k) {
  $v = get_post_meta($post_id, $k, true);
  if (!empty($v)) { $email = $v; break; }
}
?>
<main id="primary" class="site-main gd-single">
  <div class="gd-title-box">
    <h1 class="entry-title"><?php the_title(); ?> - AAA</h1>
  </div>

  <section class="gd-main-box">
    <div class="gd-map">AAAA
      <?php
        if (shortcode_exists('gd_map')) {
            echo do_shortcode('[gd_map width="100%" height="360px"]');
        } else {
            if (!empty($addr)) {
                $src = 'https://www.openstreetmap.org/export/embed.html?search=' . rawurlencode($addr) . '&marker';
                echo '<iframe style="border:0;width:100%;height:360px" loading="lazy" src="'.esc_url($src).'"></iframe>';
            } else {
                echo '<p style="opacity:.75">'.esc_html__('Mapa indisponível para este anúncio.', 'neve-child-geodir').'</p>';
            }
        }
      ?>
    </div>
    <ul class="gd-details">
      <?php if (!empty($addr)) : ?>
        <li><span class="label"><?php echo esc_html__('Endereço:', 'neve-child-geodir'); ?></span>
            <span class="value"><?php echo esc_html($addr); ?></span></li>
      <?php endif; ?>
      <?php if (!empty($phone)) : ?>
        <li><span class="label"><?php echo esc_html__('Telefone:', 'neve-child-geodir'); ?></span>
            <span class="value"><a href="tel:<?php echo esc_attr(preg_replace('/\D+/', '', $phone)); ?>"><?php echo esc_html($phone); ?></a></span></li>
      <?php endif; ?>
      <?php if (!empty($whatsapp)) : ?>
        <li><span class="label"><?php echo esc_html__('WhatsApp:', 'neve-child-geodir'); ?></span>
            <span class="value"><a target="_blank" rel="noopener" href="https://wa.me/<?php echo esc_attr($whatsapp); ?>"><?php echo esc_html($whatsapp); ?></a></span></li>
      <?php endif; ?>
      <?php if (!empty($website)) : ?>
        <li><span class="label"><?php echo esc_html__('Website:', 'neve-child-geodir'); ?></span>
            <span class="value"><a target="_blank" rel="noopener" href="<?php echo esc_url($website); ?>"><?php echo esc_html($website); ?></a></span></li>
      <?php endif; ?>
      <?php if (!empty($email)) : ?>
        <li><span class="label"><?php echo esc_html__('E-mail:', 'neve-child-geodir'); ?></span>
            <span class="value"><a href="mailto:<?php echo esc_attr($email); ?>"><?php echo esc_html($email); ?></a></span></li>
      <?php endif; ?>
    </ul>
  </section>

  <div class="gd-content-box">
    <?php the_content(); ?>
  </div>
</main>
<?php get_footer(); ?>
