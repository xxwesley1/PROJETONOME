<?php
/**
 * Optional helper: enqueue stacked tabs CSS.
 * Add this to your child theme functions.php if needed.
 */
add_action('wp_enqueue_scripts', function(){
    $css = get_stylesheet_directory_uri() . '/assets/css/geodir-tabs-stacked.css';
    wp_enqueue_style('geodir-tabs-stacked', $css, [], '1.0');
});
