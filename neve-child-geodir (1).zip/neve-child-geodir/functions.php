<?php
if (!defined('ABSPATH')) { exit; }

add_action('wp_enqueue_scripts', function(){
    wp_enqueue_style('neve-child-geodir', get_stylesheet_uri(), [], '1.0.1');
}, 20);

add_filter('single_template', function($template){
    if (is_singular('gd_place')) {
        $child = get_stylesheet_directory() . '/single-gd_place.php';
        if (file_exists($child)) return $child;
    }
    return $template;
});


/**
 * Optional helper: enqueue stacked tabs CSS.
 * Add this to your child theme functions.php if needed.
 */
add_action('wp_enqueue_scripts', function(){
    $css = get_stylesheet_directory_uri() . '/assets/css/geodir-tabs-stacked.css';
    wp_enqueue_style('geodir-tabs-stacked', $css, [], '1.0');
});

add_action('wp_enqueue_scripts', function(){
  wp_enqueue_style('geodir-tabs-boxed', get_stylesheet_directory_uri().'/assets/css/geodir-tabs-boxed.css', [], '1.0');
}, 20);

add_action('wp', function () {
  if ( is_singular('gd_place') ) {
    // Alguns sites usam este filtro para o header do Neve:
    add_filter( 'neve_show_page_title', '__return_false' );

    // Como fallback, remova o header do Neve por ação (varia por versão):
    remove_action( 'neve_page_header', 'neve_do_page_header' );
    remove_action( 'neve_do_page_header', 'neve_do_page_header' );
  }
});

// Neve: não mostrar título na single do GeoDirectory
add_filter('neve_show_page_title', function ($show) {
  if (is_singular('gd_place')) { return false; }
  return $show;
}, 99);

// Alguns layouts do Neve usam essas actions; remover se existirem:
add_action('wp', function () {
  if (is_singular('gd_place')) {
    remove_action('neve_page_header', 'neve_do_page_header');
    remove_action('neve_do_page_header', 'neve_do_page_header');
  }
}, 99);
