<?php
defined('ABSPATH') || exit;
/** Suprime o título padrão do GeoDirectory em single */
return;