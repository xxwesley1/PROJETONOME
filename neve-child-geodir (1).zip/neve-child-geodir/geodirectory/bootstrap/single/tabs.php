<?php
defined('ABSPATH') || exit;
global $post, $wpdb;

if ( ! isset( $tabs_array ) || empty( $tabs_array ) || empty( $post ) ) {
    return;
}

/**
 * Identifica abas de Mapa e Conteúdo
 */
$map_html     = '';
$content_html = '';

$match = function( $tab, $needles ) {
    $fields = array();
    if ( ! empty( $tab['tab_key'] ) )   { $fields[] = $tab['tab_key']; }
    if ( ! empty( $tab['tab_title'] ) ) { $fields[] = $tab['tab_title']; }
    if ( ! empty( $tab['title'] ) )     { $fields[] = $tab['title']; }
    $blob = strtolower( implode( ' ', $fields ) );
    foreach ( $needles as $n ) {
        if ( strpos( $blob, strtolower( $n ) ) !== false ) {
            return true;
        }
    }
    return false;
};

foreach ( $tabs_array as $tab ) {
    $html = isset( $tab['tab_content_rendered'] ) ? $tab['tab_content_rendered'] : '';
    if ( $html === '' ) {
        continue;
    }
    if ( $map_html === '' && $match( $tab, array( 'map' ) ) ) {
        $map_html = $html;
        continue;
    }
    if ( $content_html === '' && $match( $tab, array( 'content', 'description', 'descri' ) ) ) {
        $content_html = $html;
        continue;
    }
}

/**
 * Busca dados na tabela de detalhes do GeoDirectory
 */
$post_id   = $post->ID;
$post_type = get_post_type( $post_id );
$table     = $wpdb->prefix . 'geodir_' . $post_type . '_detail';

$address  = '';
$telefone = '';
$whatsapp = '';
$city     = '';
$region   = '';
$cnpj     = '';

$has_table = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );

if ( $has_table ) {
    // SELECT * permite campos extras (como cnpj)
    $row = $wpdb->get_row(
        $wpdb->prepare(
            'SELECT * FROM ' . $table . ' WHERE post_id = %d LIMIT 1',
            $post_id
        ),
        ARRAY_A
    );

    if ( $row ) {
        // Endereço
        $parts = array();
        foreach ( array( 'street', 'street2', 'city', 'region', 'zip', 'country' ) as $k ) {
            if ( ! empty( $row[ $k ] ) ) {
                $parts[] = $row[ $k ];
            }
        }
        if ( $parts ) {
            $address = implode( ', ', $parts );
        }

        // Telefones / WhatsApp
        if ( ! empty( $row['telefone'] ) ) {
            $telefone = $row['telefone'];
        }
        if ( ! empty( $row['whatsapp'] ) ) {
            $whatsapp = $row['whatsapp'];
        }

        // Cidade / Estado
        if ( ! empty( $row['city'] ) ) {
            $city = trim( $row['city'] );
        }
        if ( ! empty( $row['region'] ) ) {
            $region = trim( $row['region'] );
        }

        // CNPJ se existir na tabela
        if ( ! empty( $row['cnpj'] ) ) {
            $cnpj = trim( $row['cnpj'] );
        }
    }
}

/**
 * Fallbacks opcionais para CNPJ em postmeta
 */
if ( $cnpj === '' ) {
    foreach ( array( 'cnpj', '_cnpj', 'company_cnpj' ) as $mk ) {
        $v = get_post_meta( $post_id, $mk, true );
        if ( $v !== '' && $v !== null ) {
            $cnpj = trim( $v );
            break;
        }
    }
}

/**
 * Mapeia UF (Paraná -> PR) quando necessário
 */
$uf_map = array(
    'Acre' => 'AC', 'Alagoas' => 'AL', 'Amapá' => 'AP', 'Amazonas' => 'AM',
    'Bahia' => 'BA', 'Ceará' => 'CE', 'Distrito Federal' => 'DF', 'Espírito Santo' => 'ES',
    'Goiás' => 'GO', 'Maranhão' => 'MA', 'Mato Grosso' => 'MT', 'Mato Grosso do Sul' => 'MS',
    'Minas Gerais' => 'MG', 'Pará' => 'PA', 'Paraíba' => 'PB', 'Paraná' => 'PR',
    'Pernambuco' => 'PE', 'Piauí' => 'PI', 'Rio de Janeiro' => 'RJ', 'Rio Grande do Norte' => 'RN',
    'Rio Grande do Sul' => 'RS', 'Rondônia' => 'RO', 'Roraima' => 'RR', 'Santa Catarina' => 'SC',
    'São Paulo' => 'SP', 'Sergipe' => 'SE', 'Tocantins' => 'TO'
);

$uf = $region;
if ( $region && strlen( $region ) > 2 && isset( $uf_map[ $region ] ) ) {
    $uf = $uf_map[ $region ];
} elseif ( $region && strlen( $region ) == 2 ) {
    $uf = strtoupper( $region );
}

/**
 * Normaliza telefone/WhatsApp
 */
$tel_digits = preg_replace( '/\D+/', '', (string) $telefone );
$wa_digits  = preg_replace( '/\D+/', '', (string) $whatsapp );

/**
 * Ícones SVG
 */
$icon_phone = '<svg class="gd-ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6.62 10.79a15.05 15.05 0 0 0 6.59 6.59l2.2-2.2a1 1 0 0 1 1.03-.24c1.12.37 2.33.57 3.56.57a1 1 0 0 1 1 1V20a1 1 0 0 1-1 1C11.85 21 3 12.15 3 2a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.23.2 2.44.57 3.56a1 1 0 0 1-.25 1.03l-2.2 2.2z"/></svg>';
$icon_wa = '<svg class="gd-ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M20.52 3.48A11.94 11.94 0 0 0 12.06 0C5.44 0 .03 5.41.03 12.09c0 2.13.56 4.21 1.63 6.05L0 24l5.99-1.62a11.95 11.95 0 0 0 6.07 1.63h.01c6.64 0 12.05-5.41 12.05-12.09 0-3.22-1.26-6.25-3.6-8.44zM12.07 21.1h-.01a9.9 9.9 0 0 1-5.05-1.39l-.36-.21-3.55.96.95-3.46-.23-.36a9.93 9.93 0 0 1-1.52-5.25C2.3 6.57 6.86 2 12.06 2 17.25 2 21.8 6.57 21.8 11.86c0 5.29-4.55 9.24-9.73 9.24z"/></svg>';

/**
 * Breadcrumbs
 */
?>
<div class="gd-breadcrumb-wrap">
    <?php
    if ( function_exists( 'geodir_breadcrumb' ) ) {
        geodir_breadcrumb();
    } elseif ( shortcode_exists( 'gd_breadcrumbs' ) ) {
        echo do_shortcode( '[gd_breadcrumbs]' );
    }
    ?>
</div>
<?php
/* === Ícones SVG (garantia) === */
if ( ! isset( $icon_pin ) ) {
  $icon_pin = '<svg class="gd-ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a7 7 0 0 0-7 7c0 5.25 7 13 7 13s7-7.75 7-13a7 7 0 0 0-7-7zm0 9.5a2.5 2.5 0 1 1 0-5 2.5 2.5 0 0 1 0 5z"/></svg>';
}
if ( ! isset( $icon_phone ) ) {
  $icon_phone = '<svg class="gd-ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M6.62 10.79a15.05 15.05 0 0 0 6.59 6.59l2.2-2.2a1 1 0 0 1 1.03-.24c1.12.37 2.33.57 3.56.57a1 1 0 0 1 1 1V20a1 1 0 0 1-1 1C11.85 21 3 12.15 3 2a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.23.2 2.44.57 3.56a1 1 0 0 1-.25 1.03l-2.2 2.2z"/></svg>';
}
if ( ! isset( $icon_wa ) ) {
  $icon_wa = '<svg class="gd-ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M20.52 3.48A11.94 11.94 0 0 0 12.06 0C5.44 0 .03 5.41.03 12.09c0 2.13.56 4.21 1.63 6.05L0 24l5.99-1.62a11.95 11.95 0 0 0 6.07 1.63h.01c6.64 0 12.05-5.41 12.05-12.09 0-3.22-1.26-6.25-3.6-8.44zM12.07 21.1h-.01a9.9 9.9 0 0 1-5.05-1.39l-.36-.21-3.55.96.95-3.46-.23-.36a9.93 9.93 0 0 1-1.52-5.25C2.3 6.57 6.86 2 12.06 2 17.25 2 21.8 6.57 21.8 11.86c0 5.29-4.55 9.24-9.73 9.24z"/></svg>';
}
?>

<?php
/**
 * Box do título (Nome + Cidade/UF + endereço + avaliações)
 */

// Ratings do GeoDirectory
$ratings_html = '';
if ( shortcode_exists( 'gd_ratings' ) ) {
    $ratings_html = do_shortcode( '[gd_ratings]' );
} elseif ( function_exists( 'geodir_show_rating_stars' ) ) {
    ob_start();
    geodir_show_rating_stars( $post_id );
    $ratings_html = ob_get_clean();
}

// Claim button (GeoDirectory Claim Listings addon)
$claim_html = '';
if ( shortcode_exists( 'gd_claim_post' ) ) {
    // Addon oficial de Claim Listings: GD > Post Claim
    $claim_html = do_shortcode( '[gd_claim_post text="Minha Empresa" output="button" btn_color="warning"]' );
}
?>
<div class="gd-title-box">
    <h1 class="gd-title">
        <?php
        $base_title = get_the_title( $post_id );
        $sufixo     = '';
        if ( $city ) {
            $place = $city;
            if ( ! empty( $uf ) ) {
                $place .= ', ' . $uf;
            }
            $sufixo = ' em ' . $place;
        }
        echo esc_html( $base_title . $sufixo );
        ?>
    </h1>

    <?php if ( $address !== '' ) : ?>
        <div class="gd-subtitle">
            <span class="ico"><?php echo $icon_pin; ?></span>
            <span class="addr-text"><?php echo esc_html( $address ); ?></span>
        </div>
    <?php endif; ?>

    <?php if ( $ratings_html ) : ?>
        <div class="gd-rating-wrap">
            <?php echo $ratings_html; ?>
        </div>
    <?php endif; ?>
</div>

<?php
/**
 * Monta lista de detalhes (Telefone, WhatsApp como botão, CNPJ)
 */
$details_extra = '<ul class="gd-details-extra">';

if ( $telefone !== '' ) {
    $telLink        = $tel_digits ? '<a href="tel:' . esc_attr( $tel_digits ) . '">' . esc_html( $telefone ) . '</a>' : esc_html( $telefone );
    $details_extra .= '<li><span class="ico">' . $icon_phone . '</span><span class="label">' . esc_html__( 'Telefone:', 'neve-child-geodir' ) . '</span> <span class="value">' . $telLink . '</span></li>';
}

if ( $whatsapp !== '' ) {
    // Normaliza o número: remove tudo que não é dígito
    $wa_link_digits = preg_replace( '/\D+/', '', (string) $whatsapp );

    // Remove prefixos 00, +, +55, 055 etc.
    $wa_link_digits = preg_replace( '/^(?:00|\+?55)/', '', $wa_link_digits );
    $wa_link_digits = ltrim( $wa_link_digits, '0' );

    // Garante DDI 55 na frente
    if ( $wa_link_digits !== '' && strpos( $wa_link_digits, '55' ) !== 0 ) {
        $wa_link_digits = '55' . $wa_link_digits;
    }

    // Monta mensagem pré-preenchida
    $blog_name = get_bloginfo( 'name' );
    $title     = get_the_title( $post_id );
    $url       = get_permalink( $post_id );

    $msg = sprintf(
        'Olá, vi seu anúncio "%s" no %s e gostaria de mais informações. Link: %s',
        $title,
        $blog_name,
        $url
    );
    $msg_encoded = rawurlencode( $msg );

    if ( $wa_link_digits ) {
        $wa_url   = 'https://wa.me/' . esc_attr( $wa_link_digits ) . '?text=' . $msg_encoded;
        $waButton = '<a class="gd-btn-whatsapp" target="_blank" rel="noopener" href="' . $wa_url . '">Chamar no WhatsApp</a>';
    } else {
        $waButton = esc_html( $whatsapp );
    }

    $details_extra .= '<li class="gd-whatsapp-li"><span class="ico">' . $icon_wa . '</span><span class="label">' . esc_html__( 'WhatsApp:', 'neve-child-geodir' ) . '</span> <span class="value">' . $waButton . '</span></li>';
}

if ( $cnpj !== '' ) {
    $details_extra .= '<li><span class="ico">🔹</span><span class="label">' . esc_html__( 'CNPJ:', 'neve-child-geodir' ) . '</span> <span class="value">' . esc_html( $cnpj ) . '</span></li>';
}

$details_extra .= '</ul>';
?>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-0485896619076920"
     crossorigin="anonymous"></script>
<!-- GUINCHO LISTING -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-0485896619076920"
     data-ad-slot="1549222715"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
<!-- BOX DETALHES + MAPA -->
<div class="gd-box gd-box-details-map">
    <div class="gd-box-inner gd-grid">
        <div class="gd-col gd-details">
    <div class="gd-details-injected">
        <?php echo $details_extra; ?>

        <?php if ( $claim_html ) : ?>
            <div class="gd-actions-inline">
                <?php echo $claim_html; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
        <div class="gd-col gd-map">
            <?php
            if ( $map_html !== '' ) {
                echo $map_html;
            } elseif ( shortcode_exists( 'gd_map' ) ) {
                echo do_shortcode( '[gd_map width="100%" height="360px"]' );
            }
            ?>
        </div>
    </div>
</div>

<!-- BOX CONTEÚDO -->
<?php if ( $content_html !== '' ) : ?>
    <div class="gd-box gd-box-content">
        <div class="gd-box-inner">
            <?php echo $content_html; ?>
        </div>
    </div>
<?php endif; ?>
